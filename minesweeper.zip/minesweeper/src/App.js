import "./App.css";
import { GameBoard } from "./components/gameboard/GameBoard";

function App() {
  return (
    <div>
      <GameBoard />
    </div>
  );
}

export default App;
